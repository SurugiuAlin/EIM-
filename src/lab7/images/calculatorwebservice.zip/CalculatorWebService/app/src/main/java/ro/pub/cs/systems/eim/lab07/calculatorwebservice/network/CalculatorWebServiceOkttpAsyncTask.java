package ro.pub.cs.systems.eim.lab07.calculatorwebservice.network;

import android.os.AsyncTask;
import android.widget.TextView;
import okhttp3.*;
import ro.pub.cs.systems.eim.lab07.calculatorwebservice.general.Constants;

import javax.net.ssl.*;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

public class CalculatorWebServiceOkttpAsyncTask extends AsyncTask<String, Void, String> {

    private TextView resultTextView;

    public CalculatorWebServiceOkttpAsyncTask(TextView resultTextView) {
        this.resultTextView = resultTextView;
    }

    @Override
    protected String doInBackground(String... params) {
        String operator1 = params[0];
        String operator2 = params[1];
        String operation = params[2];
        int method = Integer.parseInt(params[3]);

        String errorMessage = null;
        if (operator1 == null || operator1.isEmpty()) {
            errorMessage = Constants.ERROR_MESSAGE_EMPTY;
        }
        if (operator2 == null || operator2.isEmpty()) {
            errorMessage = Constants.ERROR_MESSAGE_EMPTY;
        }
        if (errorMessage != null) {
            return errorMessage;
        }

        OkHttpClient httpClient = getUnsafeOkHttpClient();
        switch(method) {
            case Constants.GET_OPERATION:
                String httpGet = Constants.GET_WEB_SERVICE_ADDRESS
                        + "?" + Constants.OPERATION_ATTRIBUTE + "=" + operation
                        + "&" + Constants.OPERATOR1_ATTRIBUTE + "=" + operator1
                        + "&" + Constants.OPERATOR2_ATTRIBUTE + "=" + operator2;

                Request request = new Request.Builder()
                        .url(httpGet)
                        .build();

                try {
                    Response response = httpClient.newCall(request).execute();
                    return response.body().string();
                } catch (Exception e) {
                    return e.getMessage();
                }
            case Constants.POST_OPERATION:

                RequestBody requestBody = new MultipartBody.Builder()
                        .setType(MultipartBody.FORM)
                        .addFormDataPart(Constants.OPERATION_ATTRIBUTE, operation)
                        .addFormDataPart(Constants.OPERATOR1_ATTRIBUTE, operator1)
                        .addFormDataPart(Constants.OPERATOR2_ATTRIBUTE, operator2)
                        .build();

                Request requestPost = new Request.Builder()
                        .url(Constants.POST_WEB_SERVICE_ADDRESS )
                        .post(requestBody)
                        .build();
                try {
                    Response response = httpClient.newCall(requestPost).execute();
                    return response.body().string();
                } catch (Exception e) {
                    return e.getMessage();
                }
        }
        return null;
    }

    @Override
    protected void onPostExecute(String result) {
        resultTextView.setText(result);
    }


    private static OkHttpClient getUnsafeOkHttpClient() {
        try {
            // Create a trust manager that does not validate certificate chains
            final TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(X509Certificate[] chain,
                                                       String authType) throws CertificateException {
                        }

                        @Override
                        public void checkServerTrusted(X509Certificate[] chain,
                                                       String authType) throws CertificateException {
                        }

                        @Override
                        public X509Certificate[] getAcceptedIssuers() {
                            return new X509Certificate[0];
                        }
                    }
            };

            // Install the all-trusting trust manager
            final SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
            // Create an ssl socket factory with our all-trusting manager
            final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

            return new OkHttpClient.Builder()
                    .sslSocketFactory(sslSocketFactory, (X509TrustManager) trustAllCerts[0])
                    .hostnameVerifier(new HostnameVerifier() {
                        @Override
                        public boolean verify(String hostname, SSLSession session) {
                            return true;
                        }
                    }).build();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
